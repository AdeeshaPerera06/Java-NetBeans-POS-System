/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pos.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author home
 */
public class MyConn {
static Connection c;
    public static void getMyConn() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/POS";
        c = DriverManager.getConnection(url, "root", "adeesha@2006");
    }

    public static void Save(String sql) throws Exception{
        if(c==null)
            getMyConn();
        c.createStatement().executeUpdate(sql);
    }
    public static ResultSet Search(String sql)throws Exception{
        if(c==null)
            getMyConn();
        ResultSet rs=c.createStatement().executeQuery(sql);
        return rs;
    }
}

